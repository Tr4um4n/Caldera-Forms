<?php


namespace calderawp\calderaforms\cf2\Exceptions;


use calderawp\calderaforms\cf2\Exception;
use Psr\Container\NotFoundExceptionInterface;

class NotFoundInContainerException extends Exception implements NotFoundExceptionInterface
{

}
